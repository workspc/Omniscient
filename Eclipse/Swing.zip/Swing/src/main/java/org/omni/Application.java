package org.omni;

import java.awt.Component;

public interface Application {

	void build(Component root, Component currentComponent);
}
